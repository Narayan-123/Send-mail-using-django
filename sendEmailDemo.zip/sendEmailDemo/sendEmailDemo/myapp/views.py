from django.shortcuts import render,HttpResponse
from django.core.mail import send_mail,EmailMultiAlternatives
from sendEmailDemo.settings import EMAIL_HOST_USER
# Create your views here.
def index(request):

    if request.method=="POST":
        #fetch data from form
        sub=request.POST.get("subject")
        msg=request.POST.get("message")

        #approach1 
        #send_mail('Subject here', 'Here is the message.',  'from@example.com',  ['to@example.com'], fail_silently=False,)
        #send_mail(sub,msg,EMAIL_HOST_USER,['rajeshsaindane422@gmail.com'])

        #approach 2
        email=EmailMultiAlternatives(sub,msg,EMAIL_HOST_USER,['<email id at which you want to send message>'])
        email.attach('123.JPG','static/images')
        email.attach('124.JPG','static/images')
        email.attach('125.JPG','static/images')
        email.send()

        return HttpResponse("email sent successfully")
    else:
        return render(request,'mail.html')    


